import json, os, sys, tempfile, unittest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from nion.codes import (compose_from_segments, mask, needs_translation, unmask)
from nion.engine import Engine, EchoEngine, EngineError
from nion.extract import find_data_dir, iter_entries
from nion.memory import Memory
from nion.pipeline import apply_translations, pending_texts, scan, translate_pending


def read(path):
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)


def write(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(obj, fh)


def make_game(root, mv=False):
    d = os.path.join(root, "www", "data") if mv else os.path.join(root, "data")
    write(d + "/System.json", {"currencyUnit": "Gold", "skillTypes": ["", "Magic"],
          "terms": {"basic": ["Level"], "commands": ["Fight", None], "params": ["Max HP"],
                    "messages": {"victory": "%1 is victorious!"}}})
    write(d + "/Items.json", [None, {"name": "Potion", "description": "Heals HP."}])
    write(d + "/Map001.json", {"displayName": "Old Town", "events": [None, {"pages": [{"list": [
        {"code": 101, "indent": 0, "parameters": ["", 0, 0, 2, "Elio"]},
        {"code": 401, "indent": 0, "parameters": ["\\C[2]Hello\\C[0] world, \\N[1]!"]},
        {"code": 102, "indent": 0, "parameters": [["Yes", "No"], 1]},
        {"code": 402, "indent": 0, "parameters": [0, "Yes"]},
        {"code": 108, "indent": 0, "parameters": ["comment, do not translate"]},
        {"code": 0, "indent": 0, "parameters": []}]}]}]})
    write(d + "/MapInfos.json", [None, {"name": "editor only"}])
    return d


class BreakingEngine(Engine):
    """Falla en el segundo lote para probar la reanudación."""
    name = "breaking"
    max_batch = 2
    calls = 0

    def translate_batch(self, texts, src, tgt):
        BreakingEngine.calls += 1
        if BreakingEngine.calls == 2:
            raise EngineError("sin conexión")
        return ["T:" + t for t in texts]


class LossyEngine(Engine):
    """Pierde los marcadores -> debe activarse la traducción por trozos."""
    name = "lossy"

    def translate_batch(self, texts, src, tgt):
        return ["X:" + t.replace("\u27e6", "").replace("\u27e7", "") for t in texts]


class Tests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = self.tmp.name

    def tearDown(self):
        self.tmp.cleanup()

    def test_mask_roundtrip(self):
        t = "\\C[2]Hola\\C[0] %1 <WordWrap> \\{grande\\}"
        masked, codes = mask(t)
        self.assertNotIn("\\C", masked)
        self.assertEqual(unmask(masked, codes), t)
        self.assertIsNone(unmask(masked.replace("\u27e60\u27e7", ""), codes))

    def test_needs_translation(self):
        self.assertFalse(needs_translation("\\C[2]  %1 <br> 123"))
        self.assertTrue(needs_translation("\\C[2]Hi"))

    def test_extract_mz_and_mv(self):
        for mv in (False, True):
            with self.subTest(mv=mv):
                root = os.path.join(self.root, "mv" if mv else "mz")
                make_game(root, mv)
                data_dir = find_data_dir(root)
                texts = [e.text for e in iter_entries(data_dir)]
                for expected in ("Potion", "Heals HP.", "Old Town", "Elio", "Yes", "No",
                                 "Gold", "Magic", "Level", "Fight", "Max HP", "%1 is victorious!"):
                    self.assertIn(expected, texts)
                self.assertNotIn("comment, do not translate", texts)
                self.assertNotIn("editor only", texts)

    def test_apply_never_touches_original(self):
        root = os.path.join(self.root, "g")
        d = make_game(root)
        before = open(d + "/Items.json", encoding="utf-8").read()
        mem = Memory(os.path.join(self.root, "m.json"))
        _, entries = scan(root)
        translate_pending(entries, mem, EchoEngine(), "en", "es", log=lambda *_: None)
        out = os.path.join(self.root, "out")
        applied, missing = apply_translations(root, out, mem, log=lambda *_: None)
        self.assertEqual(open(d + "/Items.json", encoding="utf-8").read(), before)
        self.assertEqual(read(out + "/Items.json")[1]["name"], "[ES] Potion")
        self.assertEqual(read(out + "/MapInfos.json")[1]["name"], "editor only")
        self.assertGreater(applied, 5)
        with self.assertRaises(EngineError):
            apply_translations(root, d, mem, log=lambda *_: None)

    def test_codes_survive(self):
        root = os.path.join(self.root, "g")
        make_game(root)
        mem = Memory(os.path.join(self.root, "m.json"))
        _, entries = scan(root)
        translate_pending(entries, mem, EchoEngine(), "en", "es", log=lambda *_: None)
        out = os.path.join(self.root, "out")
        apply_translations(root, out, mem, log=lambda *_: None)
        line = read(out + "/Map001.json")["events"][1]["pages"][0]["list"][1]["parameters"][0]
        self.assertIn("\\C[2]", line)
        self.assertIn("\\C[0]", line)
        self.assertIn("\\N[1]", line)

    def test_fallback_when_engine_loses_placeholders(self):
        root = os.path.join(self.root, "g")
        make_game(root)
        mem = Memory(os.path.join(self.root, "m.json"))
        _, entries = scan(root)
        translate_pending(entries, mem, LossyEngine(), "en", "es", log=lambda *_: None)
        out = os.path.join(self.root, "out")
        apply_translations(root, out, mem, log=lambda *_: None)
        line = read(out + "/Map001.json")["events"][1]["pages"][0]["list"][1]["parameters"][0]
        self.assertTrue(line.startswith("\\C[2]X:Hello\\C[0]"), line)
        self.assertIn("\\N[1]", line)

    def test_resume_after_failure(self):
        root = os.path.join(self.root, "g")
        make_game(root)
        path = os.path.join(self.root, "m.json")
        _, entries = scan(root)
        BreakingEngine.calls = 0
        with self.assertRaises(EngineError):
            translate_pending(entries, Memory(path), BreakingEngine(), "en", "es", log=lambda *_: None)
        saved = len(Memory(path))
        self.assertGreater(saved, 0)                       # lo del primer lote se conservó
        mem = Memory(path)
        before = len(pending_texts(entries, mem))
        BreakingEngine.calls = 10                          # ya no falla
        translate_pending(entries, mem, BreakingEngine(), "en", "es", log=lambda *_: None)
        self.assertEqual(len(pending_texts(entries, mem)), 0)
        self.assertGreater(before, 0)

    def test_old_segment_cache_is_reused(self):
        mem = Memory(os.path.join(self.root, "m.json"))
        mem.set("Hello", "Hola")
        mem.set("world,", "mundo,")
        self.assertEqual(compose_from_segments("\\C[2]Hello\\C[0] world, \\N[1]!", mem),
                         "\\C[2]Hola\\C[0] mundo, \\N[1]!")
        self.assertIsNone(compose_from_segments("Unknown", mem))


if __name__ == "__main__":
    unittest.main()
